<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class Pengajuan extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'user_id',
        'harga_parfum_id',
        'jenis_parfum',
        'jumlah',
        'target_market',
        'catatan',
        'status'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function hargaParfum()
    {
        return $this->belongsTo(HargaParfum::class);
    }

    public function trakings()
    {
        return $this->hasMany(Traking::class);
    }

    public function pembayarans()
    {
        return $this->hasMany(Pembayaran::class);
    }
}
