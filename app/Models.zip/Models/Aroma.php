<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Aroma extends Model
{
    protected $fillable = [
        'nama_kategori',
        'biaya_kategori'
    ];
}
